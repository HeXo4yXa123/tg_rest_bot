
function App() {
window.Telegram?.WebApp?.ready();
const user = window.Telegram?.WebApp?.initDataUnsafe?.user;
  return (
    <>
      <div>
        Hello World
        Привет, {user?.first_name}!
      </div>
    
    </>
  )
}

export default App
